# 📘 MANUAL DE INSTALAÇÃO - MEME BATTLE
## Guia Completo Passo a Passo Para Iniciantes

---

## 🎯 **O QUE VOCÊ VAI APRENDER**

Este manual vai te ensinar como instalar e configurar a plataforma MEME BATTLE do zero, mesmo se você nunca mexeu com programação antes. Vamos explicar tudo de forma simples e clara!

---

## 📋 **PRÉ-REQUISITOS (O QUE VOCÊ PRECISA ANTES DE COMEÇAR)**

### 🖥️ **1. Computador com Internet**
- Windows 10/11, Mac ou Linux
- Conexão estável com a internet
- Pelo menos 4GB de RAM

### 🌐 **2. Navegador Atualizado**
- Google Chrome (recomendado)
- Firefox
- Edge
- Safari

### 💾 **3. Conta no GitHub (Gratuita)**
- Acesse: https://github.com
- Clique em "Sign up"
- Crie sua conta gratuita

---

## 🚀 **PASSO 1: CONFIGURAR O SUPABASE (BANCO DE DADOS)**

### **1.1 - Criar Conta no Supabase**
1. **Acesse**: https://supabase.com
2. **Clique em**: "Start your project"
3. **Escolha**: "Sign in with GitHub"
4. **Autorize** o Supabase a acessar sua conta GitHub:
   - Você verá uma tela de autorização do GitHub como esta:
   
   ![GitHub Authorization Screen](https://blog.teddykatz.com/assets/img/oauth-flow-prompt.png)
   
   - Confira se o pedido de acesso é do Supabase
   - Clique no botão verde "Authorize supabase"
   - Se solicitado, confirme sua senha do GitHub
   - Caso apareça alguma caixa de seleção para repositórios, marque "All repositories" para acesso completo

### **1.2 - Criar Nova Organização**
1. **No dashboard**, clique em "New organization"
2. **Nome da organização**: `Meme Battle`
3. **Plano**: Free (gratuito)
4. **Clique em**: "Create organization"

![Supabase Dashboard Interface](https://public.youware.com/users-website-assets/prod/47206d3d-c2c1-408f-90d2-02a1872b548e/og-images)

### **1.3 - Criar Novo Projeto**
1. **Clique em**: "New project"
2. **Nome do projeto**: `meme-battle-db`
3. **Senha do banco**: Crie uma senha forte (anote!)
4. **Região**: Escolha a mais próxima de você
5. **Clique em**: "Create new project"
6. **Aguarde**: 2-3 minutos para o projeto ser criado

### **1.4 - Anotar Informações Importantes**
Após o projeto ser criado, você verá:
1. **Project URL**: `https://[SEU-PROJETO].supabase.co`
2. **API Key**: Uma chave longa que começa com `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...`

⚠️ **IMPORTANTE**: Anote essas informações em um lugar seguro!

---

## 🗄️ **PASSO 2: CONFIGURAR O BANCO DE DADOS**

### **2.1 - Acessar o SQL Editor**
1. **No dashboard do Supabase**, clique em "SQL Editor"
   
   ![Ícone de Configurações](https://public.youware.com/users-website-assets/prod/47206d3d-c2c1-408f-90d2-02a1872b548e/g4acf39c1ed09767d7fe0ed1671fcbf8838d279a88391272357a9993753bc4e5deea3f863c39b51c2555b385cd6eec5ce_640.png)
   
2. **Clique em**: "New query"

### **2.2 - Executar Script de Criação das Tabelas**

![Ícone de Banco de Dados](https://public.youware.com/users-website-assets/prod/47206d3d-c2c1-408f-90d2-02a1872b548e/g3847d4db8ab2c816fb1918f62ae5eafdf5148f856137c29861bfae3d927797f310a4a72562d8d2022d14b82840dd7e76f0f1ce4261e62f667ac993e7e214cd16_640.png)

1. **Cole o seguinte código** no editor SQL:

```sql
-- CRIAÇÃO DAS TABELAS PRINCIPAIS DO MEME BATTLE

-- 1. Tabela de usuários
CREATE TABLE users (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    wallet_address TEXT UNIQUE NOT NULL,
    username TEXT,
    email TEXT,
    avatar_url TEXT,
    points INTEGER DEFAULT 0,
    ranking INTEGER DEFAULT 0,
    total_votes INTEGER DEFAULT 0,
    total_shares INTEGER DEFAULT 0,
    total_comments INTEGER DEFAULT 0,
    total_projects INTEGER DEFAULT 0,
    total_referrals INTEGER DEFAULT 0,
    daily_login_streak INTEGER DEFAULT 0,
    last_login_date DATE,
    is_admin BOOLEAN DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 2. Tabela de projetos
CREATE TABLE projects (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT,
    website_url TEXT,
    twitter_url TEXT,
    telegram_url TEXT,
    logo_url TEXT,
    created_by UUID REFERENCES users(id),
    package_type TEXT NOT NULL,
    votes_count INTEGER DEFAULT 0,
    comments_count INTEGER DEFAULT 0,
    status TEXT DEFAULT 'pending',
    admin_approved BOOLEAN DEFAULT false,
    is_trending BOOLEAN DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 3. Tabela de afiliados
CREATE TABLE affiliates (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    name TEXT NOT NULL,
    wallet_address TEXT UNIQUE NOT NULL,
    email TEXT,
    services TEXT[],
    portfolio_url TEXT,
    twitter_url TEXT,
    telegram_url TEXT,
    rating DECIMAL(3,2) DEFAULT 0.00,
    total_projects INTEGER DEFAULT 0,
    total_earnings DECIMAL(20,8) DEFAULT 0,
    status TEXT DEFAULT 'pending',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 4. Configuração de pacotes de listagem
CREATE TABLE listing_packages (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT,
    price_usdt DECIMAL(10,2) NOT NULL,
    duration_days INTEGER NOT NULL,
    max_affiliates INTEGER DEFAULT 0,
    includes_trending BOOLEAN DEFAULT false,
    includes_badges BOOLEAN DEFAULT false,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Inserir pacotes padrão
INSERT INTO listing_packages (name, description, price_usdt, duration_days, max_affiliates, includes_trending, includes_badges) VALUES
('Básico', 'Listagem básica por 30 dias', 50.00, 30, 0, false, false),
('Premium', 'Listagem premium com trending', 150.00, 60, 1, true, true),
('VIP', 'Listagem VIP com máxima visibilidade', 300.00, 90, 3, true, true);

-- 5. Configuração de gamificação
CREATE TABLE activity_points_config (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    activity_type TEXT UNIQUE NOT NULL,
    points_per_action INTEGER NOT NULL,
    daily_limit INTEGER DEFAULT -1,
    description TEXT,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Inserir configurações de pontos
INSERT INTO activity_points_config (activity_type, points_per_action, daily_limit, description) VALUES
('vote', 10, 50, 'Pontos ganhos ao votar em projetos'),
('comment', 3, 30, 'Pontos ganhos ao comentar em projetos'),
('share', 5, 20, 'Pontos ganhos ao compartilhar projetos'),
('referral', 25, -1, 'Pontos ganhos ao indicar novos usuários'),
('login', 2, 1, 'Pontos ganhos por login diário'),
('project_submission', 50, 5, 'Pontos ganhos ao submeter projetos');

-- 6. Tabela de atividades dos usuários
CREATE TABLE user_activities (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES users(id),
    activity_type TEXT NOT NULL,
    points_earned INTEGER NOT NULL,
    target_id UUID,
    description TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 7. Conquistas dos usuários
CREATE TABLE user_achievements (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES users(id),
    achievement_id TEXT NOT NULL,
    achievement_name TEXT NOT NULL,
    achievement_category TEXT NOT NULL,
    progress_value INTEGER DEFAULT 0,
    requirement_value INTEGER NOT NULL,
    unlocked_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 8. Sistema de transações
CREATE TABLE transactions (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    from_wallet TEXT NOT NULL,
    to_wallet TEXT,
    amount_usdt DECIMAL(20,8) NOT NULL,
    transaction_hash TEXT,
    transaction_type TEXT NOT NULL,
    project_id UUID REFERENCES projects(id),
    affiliate_id UUID REFERENCES affiliates(id),
    admin_wallet_amount DECIMAL(20,8) DEFAULT 0,
    admin_wallet2_amount DECIMAL(20,8) DEFAULT 0,
    meme_pool_amount DECIMAL(20,8) DEFAULT 0,
    affiliate_amount DECIMAL(20,8) DEFAULT 0,
    status TEXT DEFAULT 'pending',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 9. Pool de recompensas
CREATE TABLE meme_pool (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    total_balance DECIMAL(20,8) DEFAULT 0,
    total_distributed DECIMAL(20,8) DEFAULT 0,
    last_distribution_date TIMESTAMP WITH TIME ZONE,
    next_distribution_date TIMESTAMP WITH TIME ZONE,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Inserir registro inicial da pool
INSERT INTO meme_pool (total_balance) VALUES (0);

-- 10. Histórico de rankings
CREATE TABLE ranking_history (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    snapshot_date DATE UNIQUE NOT NULL,
    snapshot_data JSONB NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 11. Logs administrativos
CREATE TABLE admin_logs (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    admin_wallet TEXT NOT NULL,
    action_type TEXT NOT NULL,
    target_type TEXT,
    target_id UUID,
    description TEXT NOT NULL,
    metadata JSONB,
    ip_address TEXT,
    user_agent TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 12. Sistema de votos
CREATE TABLE votes (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES users(id),
    project_id UUID REFERENCES projects(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(user_id, project_id)
);

-- 13. Sistema de comentários
CREATE TABLE comments (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES users(id),
    project_id UUID REFERENCES projects(id),
    content TEXT NOT NULL,
    likes_count INTEGER DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Criar índices para melhor performance
CREATE INDEX idx_users_wallet ON users(wallet_address);
CREATE INDEX idx_projects_status ON projects(status);
CREATE INDEX idx_user_activities_user_id ON user_activities(user_id);
CREATE INDEX idx_votes_project_id ON votes(project_id);
CREATE INDEX idx_comments_project_id ON comments(project_id);
```

2. **Clique em**: "Run" (botão azul)
3. **Aguarde**: A execução do script (pode levar alguns segundos)
4. **Verifique**: Se aparecer "Success" em verde

---

## 💻 **PASSO 3: BAIXAR E CONFIGURAR O CÓDIGO**

### **3.1 - Baixar o Projeto**
1. **Acesse**: O local onde você tem os arquivos do MEME BATTLE
2. **Baixe os arquivos**:
   - `index.html`
   - `YOUWARE.md`
   - Imagens (PNG files)

### **3.2 - Criar Estrutura de Pastas**
No seu computador, crie a seguinte estrutura:
```
meme-battle/
├── index.html
├── YOUWARE.md
├── images/
│   ├── aek0x6mj2s.png
│   ├── tm118lyid9.png
│   └── screenshot_4209.png
└── README.md
```

### **3.3 - Configurar as Chaves do Supabase**
1. **Abra o arquivo**: `index.html`
2. **Procure por**: `const supabaseUrl = 'https://hzubdntnulbihvdnwrko.supabase.co'`
3. **Substitua** pelas suas informações:
   ```javascript
   const supabaseUrl = 'https://[SEU-PROJETO].supabase.co'
   const supabaseKey = '[SUA-API-KEY]'
   ```

⚠️ **IMPORTANTE**: Use as informações que você anotou no Passo 1.4!

---

## 🌐 **PASSO 4: HOSPEDAR O SITE**

### **Opção A: GitHub Pages (Gratuito)**

#### **4.1 - Criar Repositório no GitHub**

![Interface Web](https://public.youware.com/users-website-assets/prod/47206d3d-c2c1-408f-90d2-02a1872b548e/gc9f5075d234bbd861d6e2f31bbba0dd9e7ca23da616d88c82f0c092856e54f588f4b4b58679a39dea28d51576c2e81a18d253ab05987d929645c76710967f83f96_640.png)

1. **Acesse**: https://github.com
2. **Clique em**: "New repository"
3. **Nome**: `meme-battle`
4. **Marque**: "Public"
5. **Marque**: "Add a README file"
6. **Clique em**: "Create repository"

![GitHub Logo](https://public.youware.com/users-website-assets/prod/47206d3d-c2c1-408f-90d2-02a1872b548e/g4d5f219c925b1e6951d7b9501cb573a28735ddee6f3a23c4d684a15de12814c653e5d3c83c42e82d7020e94e7f81a321_640.png)

#### **4.2 - Fazer Upload dos Arquivos**
1. **No repositório criado**, clique em "uploading an existing file"
2. **Arraste todos os arquivos** do projeto para a área
3. **Escreva**: "Initial commit" na descrição
4. **Clique em**: "Commit changes"

#### **4.3 - Ativar GitHub Pages**
1. **No repositório**, clique em "Settings"
2. **No menu lateral**, clique em "Pages"
3. **Source**: "Deploy from a branch"
4. **Branch**: "main"
5. **Folder**: "/ (root)"
6. **Clique em**: "Save"
7. **Aguarde**: 5-10 minutos

Seu site estará disponível em: `https://[SEU-USUARIO].github.io/meme-battle`

### **Opção B: Vercel (Gratuito)**

#### **4.1 - Criar Conta no Vercel**
1. **Acesse**: https://vercel.com
2. **Clique em**: "Sign Up"
3. **Escolha**: "Continue with GitHub"

#### **4.2 - Importar Projeto**
1. **No dashboard**, clique em "New Project"
2. **Encontre seu repositório**: `meme-battle`
3. **Clique em**: "Import"
4. **Configure**:
   - Project Name: `meme-battle`
   - Root Directory: `./`
5. **Clique em**: "Deploy"

Seu site estará disponível em: `https://meme-battle-[HASH].vercel.app`

---

## 🦊 **PASSO 5: INSTALAR E CONFIGURAR METAMASK**

### **5.1 - Instalar MetaMask**

![Navegadores](https://public.youware.com/users-website-assets/prod/47206d3d-c2c1-408f-90d2-02a1872b548e/gbfcf3448f1d4274f50c8aba450c99967f4f497732e7760f6ac6ab30f3897d2e6953800996e851899865a83eb964b490c_640.png)

1. **Acesse**: https://metamask.io
2. **Clique em**: "Download"
3. **Escolha seu navegador**
4. **Instale a extensão**
5. **Clique no ícone** do MetaMask no navegador

### **5.2 - Criar Carteira**
1. **Clique em**: "Create a Wallet"
2. **Aceite os termos**
3. **Crie uma senha forte**
4. **Anote sua frase de recuperação** (12 palavras)
5. **Confirme a frase** na ordem correta
6. **Clique em**: "All Done"

### **5.3 - Adicionar Rede BSC**
1. **No MetaMask**, clique no dropdown da rede (Ethereum Mainnet)
2. **Clique em**: "Add network"
3. **Clique em**: "Add a network manually"
4. **Preencha**:
   - Network Name: `Smart Chain`
   - New RPC URL: `https://bsc-dataseed.binance.org/`
   - Chain ID: `56`
   - Currency Symbol: `BNB`
   - Block Explorer: `https://bscscan.com`
5. **Clique em**: "Save"

### **5.4 - Adicionar Token USDT**
1. **Na rede BSC**, clique em "Import tokens"
2. **Cole o endereço**: `0x55d398326f99059fF775485246999027B3197955`
3. **Símbolo**: `USDT`
4. **Decimais**: `18`
5. **Clique em**: "Add Custom Token"

---

## 🎮 **PASSO 6: TESTAR A PLATAFORMA**

### **6.1 - Acessar o Site**
1. **Abra seu navegador**
2. **Acesse** o endereço do seu site
3. **Verifique** se a página carrega corretamente

### **6.2 - Conectar Wallet**

![Ícone de Wallet](https://public.youware.com/users-website-assets/prod/47206d3d-c2c1-408f-90d2-02a1872b548e/g7ad13f500b0df60323216c7c5289d1ac2ceaeb439979eb2b1ab19b7077b95a5b402b5d18daf01dff979421952d910494b3cda06b1745136f33087e33ec0d49cd_640.png)

1. **Clique em**: "Conectar Wallet"
2. **Escolha**: "MetaMask"
3. **Autorize** a conexão
4. **Verifique** se seu endereço aparece no topo

### **6.3 - Testar Funcionalidades Básicas**
1. **Navegue** pelas páginas do menu
2. **Teste**: Projetos, Rankings, Dashboard
3. **Verifique** se tudo está funcionando

---

## ⚙️ **PASSO 7: CONFIGURAÇÕES AVANÇADAS (OPCIONAL)**

### **7.1 - Configurar Redes Sociais**
Para ativar a automação de posts:

#### **Twitter API**
1. **Acesse**: https://developer.twitter.com
2. **Crie uma conta** de desenvolvedor
3. **Solicite acesso** à API
4. **Obtenha** as chaves API
5. **Configure** no painel admin da plataforma

#### **Telegram Bot**
1. **Abra o Telegram**
2. **Procure por**: @BotFather
3. **Envie**: `/newbot`
4. **Siga as instruções**
5. **Obtenha** o token do bot
6. **Configure** no painel admin

### **7.2 - Configurar Wallets Administrativas**
No arquivo `index.html`, encontre:
```javascript
const adminWallets = [
    '0xd7A8484fD713D28870FCd4ad198fAB9e3ffDedB1',
    '0x2DFBe17132E0a5D9c92c94faA003505bE0588B9a'
];
```

**Substitua** pelos endereços das suas carteiras administrativas.

---

## 🔧 **SOLUÇÃO DE PROBLEMAS COMUNS**

### **❌ "Erro de Conexão com o Banco"**
**Solução**:
1. Verifique se as chaves do Supabase estão corretas
2. Confirme se o projeto está ativo no Supabase
3. Teste a conexão no SQL Editor

### **❌ "MetaMask não Conecta"**
**Solução**:
1. Verifique se a extensão está instalada
2. Refresh a página
3. Desbloquear o MetaMask
4. Autorizar o site nas configurações

### **❌ "Site não Carrega"**
**Solução**:
1. Verifique se todos os arquivos foram uploaded
2. Aguarde alguns minutos para propagação
3. Limpe o cache do navegador
4. Teste em uma aba anônima

### **❌ "Transações Falham"**
**Solução**:
1. Verifique se tem BNB para gas
2. Confirme se está na rede BSC
3. Verifique se tem USDT suficiente
4. Tente aumentar o gas limit

---

## 📞 **SUPORTE E AJUDA**

### **🔗 Links Úteis**
- **Supabase Docs**: https://supabase.com/docs
- **MetaMask Help**: https://metamask.zendesk.com
- **GitHub Pages**: https://pages.github.com
- **Vercel Docs**: https://vercel.com/docs

### **💬 Comunidade**
- **Discord**: Entre no servidor da comunidade
- **Telegram**: Grupo de suporte técnico
- **GitHub Issues**: Reporte bugs no repositório

---

## 🎉 **PARABÉNS! INSTALAÇÃO CONCLUÍDA**

![Check Success](https://public.youware.com/users-website-assets/prod/47206d3d-c2c1-408f-90d2-02a1872b548e/g48c988a7f410c0157d1a044ec2ae60cd8f5b5617de497a700d4a67fba644f9544330894eb9d4cc7c8341d10a86884b35549e9ca3e2f7e2215d4ff564a5069850_640.png)

Se você chegou até aqui, sua plataforma MEME BATTLE está:

✅ **Hospedada** e acessível na internet  
✅ **Conectada** ao banco de dados  
✅ **Integrada** com MetaMask  
✅ **Configurada** para USDT/BSC  
✅ **Pronta** para receber usuários  

### **🚀 Próximos Passos**
1. **Divulgue** sua plataforma
2. **Monitore** as métricas no admin
3. **Ajuste** configurações conforme necessário
4. **Expand** com novas funcionalidades

**Boa sorte com seu projeto!** 🚀

---

*Manual criado em [Data] - Versão 1.0*
*Para dúvidas, consulte a documentação técnica ou entre em contato com o suporte.*