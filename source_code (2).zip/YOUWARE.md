# MEME BATTLE - Plataforma Gamificada de Projetos Cripto

## Arquitetura do Projeto

### Stack Tecnológico
- **Frontend**: HTML5, CSS3, JavaScript vanilla
- **Backend**: Supabase (PostgreSQL)
- **Blockchain**: Web3.js para integração com wallets
- **Pagamentos**: USDT (BEP-20) via Smart Contracts

### Estrutura do Banco de Dados (Supabase)
**Projeto Supabase**: `meme-battle-db` (ID: hzubdntnulbihvdnwrko)
**Organização**: Meme Batlle (ID: frpopcyenawsqwtwncob)

#### Tabelas Principais:
- `users`: Usuários com wallet_address, points, ranking, gamificação
- `projects`: Projetos listados com informações, votos e pacotes
- `affiliates`: Afiliados cadastrados com serviços, ratings e wallets
- `transactions`: Histórico completo de transações e divisão de pagamentos
- `rewards`: Distribuição de recompensas da Meme Pool
- `listing_packages`: Pacotes de listagem (Básico, Premium, VIP)
- `advertisements`: Sistema de anúncios com carrossel
- `user_activities`: Log de atividades para gamificação
- `activity_points_config`: Configuração de pontos por atividade

### Sistema de Autenticação
- **Web3 Only**: Login exclusivo via wallet (MetaMask, WalletConnect)
- Criação automática de usuário no primeiro login
- Sessão gerenciada via localStorage + Supabase

### Smart Contracts (USDT BEP-20)
#### Wallets do Sistema:
- **Meme Pool**: `0xd2B3A0310DAa4aD4Ce508C1ccda9acd9C83f634b`
- **Admin Principal**: `0xd7A8484fD713D28870FCd4ad198fAB9e3ffDedB1`
- **Admin Secundário**: `0x2DFBe17132E0a5D9c92c94faA003505bE0588B9a`

#### Divisão de Pagamentos:
- 30% → Meme Pool (recompensas usuários)
- 35% → Wallet Principal
- 35% → Wallet Secundária
- Valor específico → Afiliado (quando aplicável)

### Sistema de Gamificação
#### Pontuação por Engajamento:
- Votar em projetos: +10 pontos
- Compartilhar projeto: +5 pontos
- Indicar amigos: +25 pontos
- Login diário: +2 pontos

#### Rankings:
- TOP PROJETOS (por votos, badges, trending)
- TOP USUÁRIOS (por engajamento total)
- Atualização em tempo real

### Fases de Desenvolvimento

#### FASE 1 ✅ - Estrutura Base
- Layout responsivo com menu de navegação
- Autenticação Web3 (MetaMask/WalletConnect)
- Criação automática de usuários no Supabase
- Interface inicial com hero section e features
- Logo da plataforma com animações
- Database schema completo configurado

#### FASE 2 ✅ - Sistema de Listagem
- Formulário de listagem de projetos
- Seleção de pacotes de listagem
- Escolha de afiliados por pacote
- Páginas individuais de projetos com modal detalhado
- Sistema de comentários e votos funcionais

#### FASE 3 ✅ - Sistema de Afiliados
- Página de cadastro de afiliados com formulário completo
- Listagem de afiliados aprovados com filtros
- Dashboard de ganhos para afiliados
- Sistema de avaliações e portfolio
- Vinculação afiliado-projeto funcional

#### FASE 4 ✅ - Smart Contract
- Sistema completo de pagamentos USDT (BEP-20)
- Integração com BSC Mainnet/Testnet
- Distribuição automática: 30% Meme Pool + 35% Admin1 + 35% Admin2
- Dashboard com saldos, transações e monitoramento
- Calculadora de distribuição de pagamentos
- Sistema de claim de recompensas da Meme Pool
- Verificação de rede e troca automática para BSC

#### FASE 5 ✅ - Recompensas
- Sistema completo de recompensas automáticas
- Distribuição baseada em pontos de engajamento
- Pool global com 30% das receitas da plataforma
- Cronograma automático de distribuição (domingos)
- Interface completa com estatísticas e histórico
- Sistema de indicação com links personalizados
- Monitor em tempo real de atividades
- Ranking de top participantes
- Claim individual de recompensas em USDT
- Dashboard administrativo para gestão da pool

#### FASE 6 ✅ - Rankings
- Sistema completo de rankings em tempo real
- Top projetos por votos, comentários e engajamento
- Top usuários por pontos, votos, indicações e projetos
- Sistema de conquistas/badges por categoria
- Filtros por período (hoje, semana, mês, todos os tempos)
- Auto-refresh automático a cada 30 segundos
- Comparação entre usuários
- Identificação de projetos trending
- Interface personalizada para usuário logado
- Estatísticas detalhadas por categoria
- Sistema de progresso de conquistas
- Rankings históricos e tendências

#### FASE 7 ✅ - Publicidade
- Carrossel de anúncios automatizado na Home
- Anúncios laterais na página de Projetos
- Sistema completo de gestão de publicidade
- Pacotes de duração variada (3, 7, 15, 30 dias)
- Upload de imagens e configuração de destino
- Painel administrativo para gerenciar anúncios
- Estatísticas detalhadas (impressões, cliques, CTR)
- Tracking de visitantes únicos
- Expiração automática de anúncios
- Sistema de pagamento integrado com USDT
- Visualização e gestão de anúncios ativos

#### FASE 8 ✅ - Painel Admin
- Acesso restrito por wallets autorizadas
- Dashboard completo com estatísticas da plataforma
- Sistema de notificações administrativas
- Gerenciamento de projetos (aprovação/rejeição)
- Controle de afiliados com aprovação manual
- Monitoramento de usuários e atividades
- Painel financeiro com transações e receitas
- Configurações do sistema editáveis
- Logs detalhados de todas as ações administrativas
- Interface responsiva e moderna
- Segurança com verificação de permissões

#### FASE 9 ✅ - Redes Sociais
- Sistema completo de automação para redes sociais
- Integração preparada para Twitter e Telegram APIs
- Templates personalizáveis para diferentes eventos
- Posts automáticos para aprovações e marcos
- Painel administrativo para gerenciar campanhas
- Sistema de agendamento com cooldown inteligente
- Logs detalhados de todas as atividades sociais
- Configurações individuais por plataforma
- Estatísticas de performance dos posts
- Sistema de retry para posts falhados
- Interface para testes e preview de conteúdo

### Configurações Importantes

#### Supabase Config:
```javascript
const supabaseUrl = 'https://hzubdntnulbihvdnwrko.supabase.co'
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...'
```

#### Web3 Integration:
- Detecção automática de MetaMask
- Reconexão automática na recarga
- Monitoramento de mudanças de conta

### Responsividade
- Design mobile-first
- Breakpoints para tablet e desktop
- Menu responsivo com collapse

### Performance
- Lazy loading para conteúdo dinâmico
- Otimização de queries no Supabase
- Cache de dados do usuário logado

### Segurança
- Validação de wallets autorizadas para admin
- Sanitização de inputs do usuário
- Rate limiting em ações de engajamento
- Verificação de assinaturas Web3 para transações críticas